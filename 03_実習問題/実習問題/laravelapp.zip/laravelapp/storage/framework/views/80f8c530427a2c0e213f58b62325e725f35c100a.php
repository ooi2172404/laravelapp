<html>
<head>
   <title>Jissyu/Index</title>
   <style>
   body {font-size:16pt; color:#999; }
   h1 { font-size:50pt; text-align:right; color:#f6f6f6;
       margin:-20px 0px -30px 0px; letter-spacing:-4pt; }
   </style>
</head>
<body>
    <h1>Blade/Index</h1>
    <p><?php echo e($msg); ?></p>
 </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu/output.blade.php ENDPATH**/ ?>