<li><?php echo e($item['name']); ?> [<?php echo e($item['mail']); ?>]</li>
<?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/components/item.blade.php ENDPATH**/ ?>