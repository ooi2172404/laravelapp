<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報更新画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/jissyu11/update" method="post">
   <table>
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
      <tr><th>name: </th><td><input type="text" name="name"
         value="<?php echo e($item->name); ?>"></td></tr>
      <tr><th>mail: </th><td><input type="text" name="mail"
         value="<?php echo e($item->mail); ?>"></td></tr>
      <tr><th>age: </th><td><input type="text" name="age"
         value="<?php echo e($item->age); ?>"></td></tr>
      <tr><th></th><td><input type="submit"
         value="更新"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu5_2/edit.blade.php ENDPATH**/ ?>