<?php $__env->startSection('title', 'Kouka'); ?>

<?php $__env->startSection('menu_title'); ?>
検索エンジン一覧画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="/kouka2_1/find" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="input" value="<?php echo e($input); ?>">
    <input type="submit" value="検索">
    </form>
   <table>
   <tr><th>Name</th><th>URL</th></tr>
   <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
           <td><?php echo e($item->message); ?></td>
           <td><?php echo e($item->url); ?></td>
       </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kouka2_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/kouka2_1/index.blade.php ENDPATH**/ ?>