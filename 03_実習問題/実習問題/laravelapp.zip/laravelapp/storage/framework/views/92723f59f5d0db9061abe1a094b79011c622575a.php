<style>
    .pagination { font-size:10pt; }
    .pagination li { display:inline-block }
    tr th a:link { color: white; }
    tr th a:visited { color: white; }
    tr th a:hover { color: white; }
    tr th a:active { color: white; }
 </style>
<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報一覧画面

<?php if(Auth::check()): ?>
<p>USER: <?php echo e($user->name . ' (' . $user->email . ')'); ?></p>
<?php else: ?>
<p>※ログインしていません。（<a href="/login/auth">ログイン</a></p>
<?php endif; ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <form action="/jissyu7_1/find" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="input" value="<?php echo e($input); ?>">
    <input type="submit" value="検索">
    </form>
    <?php if($errors->has('input')): ?>
    <font color="red"><?php echo e($errors->first('input')); ?></font><br>
    <?php endif; ?>
   <a href="/jissyu7_1/create">新規登録</a>
   <table>
   <tr>
       <th><a href="/jissyu7_1?sort=id">id</a></th>
       <th><a href="/jissyu7_1?sort=name">name</a></th>
       <th><a href="/jissyu7_1?sort=mail">mail</a></th>
       <th><a href="/jissyu7_1?sort=age">age</a></th>
       <th>Select</th>
       <th>Update</th>
       <th>Delete</th>
    </tr>
   <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
           <td><?php echo e($item->id); ?></td>
           <td><?php echo e($item->name); ?></td>
           <td><?php echo e($item->mail); ?></td>
           <td><?php echo e($item->age); ?></td>
           <td><a href="/jissyu7_1/<?php echo e($item->id); ?>">詳細</a></td>
           <td><a href="/jissyu7_1/<?php echo e($item->id); ?>/edit">更新</a></td>
           <td><a href="/jissyu7_1/<?php echo e($item->id); ?>/del">削除</a></td>
           <!--GET送信に注意。テキスト299Pを参考のうえ、作成すること。 -->
       </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
   <?php echo e($items->appends(['sort' => $sort])->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu7_1/index.blade.php ENDPATH**/ ?>