<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報入力画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <p><?php echo e($msg); ?></p>
   <?php if(count($errors) > 0): ?>
   <p>入力に問題があります。再入力して下さい。</p>
   <?php endif; ?>
   <table>
   <form action="/jissyu6" method="post">
       <?php echo csrf_field(); ?>
       <?php if($errors->has('name')): ?>
       <tr><th>ERROR</th><td><?php echo e($errors->first('name')); ?></td></tr>
       <?php endif; ?>
       <tr><th>名前　: </th><td><input type="text" name="name"
           value="<?php echo e(old('name')); ?>"></td></tr>
       <?php if($errors->has('mail')): ?>
       <tr><th>ERROR</th><td><?php echo e($errors->first('mail')); ?></td></tr>
       <?php endif; ?>
       <tr><th>メール: </th><td><input type="text" name="mail"
           value="<?php echo e(old('mail')); ?>"></td></tr>
       <?php if($errors->has('age')): ?>
       <tr><th>ERROR</th><td><?php echo e($errors->first('age')); ?></td></tr>
       <?php endif; ?>
       <tr><th>年齢　: </th><td><input type="text" name="age"
           value="<?php echo e(old('age')); ?>"></td></tr>
       <tr><th></th><td><input type="submit" value="send"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu/input3.blade.php ENDPATH**/ ?>