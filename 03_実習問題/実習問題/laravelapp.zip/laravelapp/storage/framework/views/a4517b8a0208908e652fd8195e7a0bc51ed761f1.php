<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザログイン画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p><?php echo e($message); ?></p>
   <form action="/login/auth" method="post">
   <table>
      <?php echo csrf_field(); ?>
      <tr><th>mail: </th><td><input type="text"
            name="email"></td></tr>
      <tr><th>pass: </th><td><input type="password"
            name="password"></td></tr>
      <tr><th></th><td><input type="submit"
            value="send"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu7_1/login.blade.php ENDPATH**/ ?>