<li><?php echo e($item['version']); ?>[<?php echo e($item['release']); ?>]</li>
<?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/components/version.blade.php ENDPATH**/ ?>