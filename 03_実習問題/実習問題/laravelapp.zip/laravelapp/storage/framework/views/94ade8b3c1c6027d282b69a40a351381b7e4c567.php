<?php $__env->startSection('title', 'Kouka'); ?>

<?php $__env->startSection('menu_title'); ?>
検索エンジン詳細画面

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <table>
   <tr><th>Name</th><th>URL</th></tr>
       <tr>
           <td><?php echo e($item->message); ?></td>
           <td><?php echo e($item->url); ?></td>
       </tr>
   </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kouka2_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/kouka2_1/show.blade.php ENDPATH**/ ?>