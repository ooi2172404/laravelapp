<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報新規登録画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/jissyu11/create" method="post">
   <table>
      <?php echo csrf_field(); ?>
      <tr><th>name: </th><td><input type="text" name="name"></td></tr>
      <tr><th>mail: </th><td><input type="text" name="mail"></td></tr>
      <tr><th>age: </th><td><input type="text" name="age"></td></tr>
      <tr><th></th><td><input type="submit" value="新規登録"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu5_2/add.blade.php ENDPATH**/ ?>