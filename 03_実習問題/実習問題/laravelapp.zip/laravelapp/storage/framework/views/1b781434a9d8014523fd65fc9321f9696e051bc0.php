<?php $__env->startSection('title', 'Kouka'); ?>

<?php $__env->startSection('menu_title'); ?>
フレームワークについて
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu_content'); ?>

<?php $__env->startComponent('components.menu'); ?>
<?php $__env->slot('menu_title'); ?>
他のWEBアプリケーションとの比較と動向
<?php $__env->endSlot(); ?>

<?php $__env->slot('menu_content'); ?>
<p>バックエンドフレームワークにおいて、PHPのLaravel、PythonのDjango、RubyのRuby on Railsが３大バックエンドフレームワークと見なされることもある。</p>
<?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginalce5b45c4640924f87f7f8f5b11a74e2f63e75c2a)): ?>
<?php $component = $__componentOriginalce5b45c4640924f87f7f8f5b11a74e2f63e75c2a; ?>
<?php unset($__componentOriginalce5b45c4640924f87f7f8f5b11a74e2f63e75c2a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.subview', ['subview_title'=>'Laravelの名前の由来',
'subview_content'=>'Laravelの名前は「ナルニア国物語」に登場するナルニア王国の王都、ケア・パラベルにちなむ。'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kouka1_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/kouka1_1/index.blade.php ENDPATH**/ ?>