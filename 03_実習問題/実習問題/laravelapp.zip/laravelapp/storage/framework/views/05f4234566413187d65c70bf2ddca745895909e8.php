<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
Laravelについて
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu_content'); ?>
<ul>
    <li>特徴</li>
    <li>バージョン</li>
</ul>
<?php $__env->startComponent('components.menu'); ?>
<?php $__env->slot('menu_title'); ?>
特徴
<?php $__env->endSlot(); ?>

<?php $__env->slot('menu_content'); ?>
<p>Laravelは、MVCのWebアプリケーション開発用の無料・オープンソースの
PHPで書かれたWebアプリケーションフレームワークである。</p>
<?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginalce5b45c4640924f87f7f8f5b11a74e2f63e75c2a)): ?>
<?php $component = $__componentOriginalce5b45c4640924f87f7f8f5b11a74e2f63e75c2a; ?>
<?php unset($__componentOriginalce5b45c4640924f87f7f8f5b11a74e2f63e75c2a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>開発元：Taylor Otwell</p>
<p>初版：2011年6月</p>
<p>プログラミング言語：PHP</p>
<p>対応OS：クロスプラットフォーム</p>
<p>公式サイト：laravel.com</p>

<?php echo $__env->make('components.subview', ['subview_title'=>'バージョン',
'subview_content'=>'2020年3月より最新バージョンは7。PHPは7.2.5以上。'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu3_3/index.blade.php ENDPATH**/ ?>