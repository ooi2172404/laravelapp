<?php $__env->startSection('title', 'Kouka'); ?>

<?php $__env->startSection('menu_title'); ?>
検索エンジン削除画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/kouka2_2/remove" method="post">
   <table>
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
      <tr><th>Name: </th><td><?php echo e($item->message); ?></td></tr>
      <tr><th>URL: </th><td><?php echo e($item->url); ?></td></tr>
      <tr><th></th><td><input type="submit" value="削除"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kouka2_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/kouka2_2/del.blade.php ENDPATH**/ ?>