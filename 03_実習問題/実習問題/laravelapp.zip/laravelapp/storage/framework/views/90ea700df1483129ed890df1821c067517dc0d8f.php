<style>
    .subview { border:double 4px #ccc; margin:10px; padding:10px;
       background-color:#fafafa; }
    .subview_title { margin:10px 20px; color:#999;
       font-size:16pt; font-weight:bold; }
    .subview_content {margin:10px 20px; color:#aaa;
       font-size:12pt; }
    </style>
    <div class="subview">
       <p class="subview_title"><?php echo e($subview_title); ?></p>
       <p class="subview_content"><?php echo e($subview_content); ?></p>
    </div>
<?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/components/subview.blade.php ENDPATH**/ ?>