<html>
<head>
   <title>Jissyu/Index</title>
   <style>
   body {font-size:16pt; color:#999; }
   h1 { font-size:50pt; text-align:right; color:#f6f6f6;
       margin:-20px 0px -30px 0px; letter-spacing:-4pt; }
   </style>
</head>
<body>
    <h1>Blade/Index</h1>
    <ol>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($loop->first): ?>
    <p>データ一覧</p>
    <?php endif; ?>
    <li>No,<?php echo e($loop->iteration); ?>.<?php echo e($item); ?></li>
    <?php if($loop->last): ?>
    <p>ここまで出力</p>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu/output2.blade.php ENDPATH**/ ?>