<style>
    .content { border:double 4px #ccc; margin:10px; padding:10px;
       background-color:#fafafa; }
    .content_title { margin:10px 20px; color:#999;
       font-size:16pt; font-weight:bold; }
    .content_content {margin:10px 20px; color:#aaa;
       font-size:12pt; }
    </style>
    <div class="content2">
       <p class="content_title"><?php echo e($content_title); ?></p>
       <p class="content_content"><?php echo e($content_content); ?></p>
    </div>
<?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/components/content.blade.php ENDPATH**/ ?>