<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報確認画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <ol>
    <p>入力の確認をお願い致します。</p>
    
    <p>名前　:<?php echo e($data['name']); ?></p>
    <p>メール:<?php echo e($data['mail']); ?></p>
    <p>年齢　:<?php echo e($data['age']); ?></p>

    <p>入力にお間違えはないでしょうか。</p>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu4_1/output.blade.php ENDPATH**/ ?>