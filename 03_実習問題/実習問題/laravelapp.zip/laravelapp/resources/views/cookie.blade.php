<!DOCTYPE html>
<html lang="ja">
  <body>
    <p>カウンター表示：{{$value}}<p>
  </body>
</html>