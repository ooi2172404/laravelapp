<li>{{$item['name']}} [{{$item['mail']}}]</li>
