<?php $__env->startSection('title', 'Jissyu'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報詳細画面

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <table>
   <tr><th>Name(Age)</th><th>Mail</th></tr>
       <tr>
           <td><?php echo e($item->getData()); ?></td>
           <td><?php echo e($item->mail); ?></td>
       </tr>
   </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.jissyu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/jissyu7_1/show.blade.php ENDPATH**/ ?>