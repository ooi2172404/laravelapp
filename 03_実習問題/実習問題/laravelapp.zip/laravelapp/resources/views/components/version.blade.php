<li>{{$item['version']}}[{{$item['release']}}]</li>
