<?php $__env->startSection('title', 'Kouka'); ?>

<?php $__env->startSection('menu_title'); ?>
検索エンジン更新画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
   <form action="/kouka2_2/update" method="post">
   <table>
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
      <tr><th>Name: </th><td><input type="text" name="message"
         value="<?php echo e($item->message); ?>"></td></tr>
      <tr><th>URL: </th><td><input type="text" name="url"
         value="<?php echo e($item->url); ?>"></td></tr>
      <tr><th></th><td><input type="submit"
         value="更新"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kouka2_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/kouka2_2/edit.blade.php ENDPATH**/ ?>