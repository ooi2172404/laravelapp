<?php $__env->startSection('title', 'Kouka'); ?>

<?php $__env->startSection('menu_title'); ?>
ユーザ情報入力画面
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <p>必要事項を記入してください。</p>
   <?php if(count($errors) > 0): ?>
   <p>入力に問題があります。再入力して下さい。</p>
   <?php endif; ?>
   <table>
   <form action="/kouka1_2" method="post">
       <?php echo csrf_field(); ?>
       <tr><th>名　　　前: </th><td><input type="text" name="name" value="<?php echo e(old('name')); ?>"></td></tr>
       <tr><th></th><td>※必須項目。10文字以内。</td></tr>
       <?php if($errors->has('name')): ?>
       <tr><th></th><td><font color="red"><?php echo e($errors->first('name')); ?></font></td></tr>
       <?php endif; ?>
       <tr><th>年　　　齢: </th><td><input type="text" name="age" value="<?php echo e(old('age')); ?>"></td></tr>
       <tr><th></th><td>※必須項目。0～150の入力。</td></tr>
       <?php if($errors->has('age')): ?>
       <tr><th></th><td><font color="red"><?php echo e($errors->first('age')); ?></font></td></tr>
       <?php endif; ?>
       <tr><th>メ　ー　ル: </th><td><input type="text" name="mail" value="<?php echo e(old('mail')); ?>"></td></tr>
       <tr><th></th><td>※必須項目。</td></tr>
       <?php if($errors->has('mail')): ?>
       <tr><th></th><td><font color="red"><?php echo e($errors->first('mail')); ?></font></td></tr>
       <?php endif; ?>
       <tr><th>学　校　名: </th><td><input type="text" name="school" value="<?php echo e(old('school')); ?>" size="40"></td></tr>
       <tr><th></th><td>※必須項目。20文字以内の入力。</td></tr>
       <?php if($errors->has('school')): ?>
       <tr><th></th><td><font color="red"><?php echo e($errors->first('school')); ?></font></td></tr>
       <?php endif; ?>
       <tr><th></th><td><input type="submit" value="send"></td></tr>
   </table>
   </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
copyright 2020 東京情報クリエイター工学院専門学校.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.kouka1_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/kouka1_2/input.blade.php ENDPATH**/ ?>